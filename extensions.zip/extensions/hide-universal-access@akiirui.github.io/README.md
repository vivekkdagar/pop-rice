# Hide Universal Access

A GNOME Shell extension to hide **Universal Access** icon from the status bar.
